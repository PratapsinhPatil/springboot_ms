# spring-cloud-zuul
How to configure SpringCloud Zuul  Routing and Filtering | SpringBoot
http://localhost:8080/doctor-api/getDS

