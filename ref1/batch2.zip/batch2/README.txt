

http://localhost:8081/actuator/loggers





https://github.com/final-demos/spring-boot-ribbon

java -jar target\ribbon-server-0.0.1-SNAPSHOT.jar --server.port=9091





https://github.com/ibmpariwesh/SpringBoot_ActiveMQ



https://github.com/ibmpariwesh/citi-morning-23-may-batch
https://github.com/final-demos/sleuth-zipkin


mvn spring-boot:run









https://github.com/ibmpariwesh/citi-23-may-batch2


git repo 
https://github.com/ibmpariwesh/citi-batch2-config


https://github.com/final-demos/spring-boot-ribbon

java -jar target\ribbon-server-0.0.1-SNAPSHOT.jar --server.port=9091

<dependency>
    <groupId>jakarta.xml.bind</groupId>
    <artifactId>jakarta.xml.bind-api</artifactId>
    <version>2.3.2</version>
</dependency>




<!-- Runtime, com.sun.xml.bind module -->
<dependency>
    <groupId>org.glassfish.jaxb</groupId>
    <artifactId>jaxb-runtime</artifactId>
    <version>2.3.2</version>
</dependency>